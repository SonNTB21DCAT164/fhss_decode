import numpy as np

# Đọc dữ liệu từ file
embedded_audio = np.loadtxt("embedded_audio.txt")
original_audio = np.loadtxt("original_audio.txt")
with open("Fs_tach.txt") as f:
    Fs = int(f.read().strip())

# PN_seq va frequencies (bo to hop tan) da su dung o qua trinh giau tin
PN_seq = np.array([
    1, 2, 3, 0, 0, 3, 4, 0, 3, 1, 4, 3, 1, 4, 4, 0, 5, 5, 0, 5, 1, 5, 0, 0, 5, 4, 2, 1, 1, 4, 1, 3, 2, 3, 2,
    0, 3, 0, 1, 1, 4, 0, 0, 0, 3, 0, 5, 3, 1, 3, 3, 5, 5, 3, 2, 2, 3, 4, 0, 5, 4, 5, 3, 2, 2, 0, 3, 2, 2, 1,
    3, 4, 1, 2, 2, 2, 5, 5, 2, 1, 3, 2, 1, 4, 5, 0, 3, 0, 4, 3, 1, 2, 4, 1, 4, 0, 1, 2, 3, 2, 2, 0, 0, 5, 0,
    5, 2, 3, 0, 5, 3, 2, 5, 4, 1, 5, 5, 0, 5, 0, 2, 1, 0, 4, 2, 3, 0, 0, 3, 4, 0, 3, 5, 4, 2, 3, 4, 4, 3, 2,
    0, 2, 2, 5, 1, 2, 0, 5, 4, 4, 2, 4, 0, 5, 0, 1, 4, 5, 1, 5, 1, 4, 4, 5, 4, 4, 4, 4, 4, 4, 4, 0, 5, 1, 3,
    2, 5, 4, 1, 0, 5, 3, 5, 4, 5, 1, 5, 2, 4, 5, 4, 2, 1, 5, 2, 0, 1, 5, 0, 3, 0, 0, 4, 0, 1, 1, 3, 5, 0, 4,
    4, 5, 0, 3, 5, 3, 4, 5, 1, 2, 4, 3, 5, 1, 3, 1, 1, 3, 2, 2, 2, 1, 0, 4, 1, 5, 4, 1, 2, 0, 3, 2, 2, 2, 1,
    2, 1, 4, 1, 4, 4, 0, 3, 2, 0, 4, 2, 1, 4, 0, 3, 1, 1, 3, 2, 4, 1, 1, 0, 2, 4, 5, 5, 2, 0, 1, 2, 3, 3, 5,
    0, 1, 3, 0, 3, 1, 3, 4, 0, 4, 1, 2, 2, 3, 0, 1, 0, 4, 0, 0, 0, 4, 4, 5
])

frequencies = np.array([1000., 1800., 2600., 3400., 4200., 5000.])

# Tính hiệu tin
extracted_signal = embedded_audio - original_audio

# Giải điều chế tín hiệu
T_bit = 0.01
Ts = 1 / Fs
t = np.arange(0, T_bit, Ts)
recovered_bits = []

for i in range(len(PN_seq)):
    f = frequencies[PN_seq[i]]  # Lay lai tan so da su dung tai vi tri i
    carrier = np.sin(2 * np.pi * f * t)  # Song mang voi tan so tuong ung
    correlation = np.sum(extracted_signal[i * len(t):(i + 1) * len(t)] * carrier)
    recovered_bits.append(int(correlation > 0))  # Xac dinh bit dua vao tuong quan tin hieu

# Chuoi dong bo hoa da su dung o qua trinh giau tin
sync_sequence = "10101010" * 3
sync_bits = [int(b) for char in sync_sequence for b in format(ord(char), '08b')]

# Tim vi tri bat dau du lieu that
for start in range(len(recovered_bits) - len(sync_bits)):
    if recovered_bits[start:start + len(sync_bits)] == sync_bits:
        recovered_bits = recovered_bits[start + len(sync_bits):]
        break

# Chuyen bit ve thong diep goc
recovered_text = "".join(
    chr(int("".join(map(str, recovered_bits[i:i + 8])), 2)) for i in range(0, len(recovered_bits), 8)
)

# Luu ket qua
with open("recovered_message.txt", "w", encoding="utf-8") as f:
    f.write(recovered_text)

print("Thong diep giai ma: ", recovered_text)
