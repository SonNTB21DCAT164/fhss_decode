import numpy as np
from scipy.io.wavfile import read

# Doc file am thanh da giau tin va file goc
Fs, embedded_audio = read("fhss_output_29s.wav")
_, original_audio = read("sample_29s.wav")

# Chuyen ve float
embedded_audio = embedded_audio.astype(float)
original_audio = original_audio.astype(float)

# Neu la stereo -> Chuyen ve mono
if embedded_audio.ndim > 1:
    embedded_audio = np.mean(embedded_audio, axis=1)
if original_audio.ndim > 1:
    original_audio = np.mean(original_audio, axis=1)

# Luu du du lieu da xu ly ra file
np.savetxt("embedded_audio.txt", embedded_audio)
np.savetxt("original_audio.txt", original_audio)

with open("Fs_tach.txt", "w") as f:
    f.write(str(Fs))

print("Tien xu ly du lieu thanh cong!")
